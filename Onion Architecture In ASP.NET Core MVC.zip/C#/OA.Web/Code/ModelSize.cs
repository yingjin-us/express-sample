﻿namespace OA.Web.Code
{
    public enum ModalSize
    {
        Small,
        Large,
        Medium
    }
}